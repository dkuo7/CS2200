to run:
	open circuit in logisim
	load benchmark.img into I-MEM and D-MEM subcircuits
	enable clock ticks
	
number of clock ticks: 1067
speedup: 1246/1067 = 1.168
	
grade i think i deserve:
	102/100
	
	-program works (65536 stored in ANS)
	-branch prediction (branch not taken) implemented for speedup
	
sample commands given in SampleCommandsConv.txt